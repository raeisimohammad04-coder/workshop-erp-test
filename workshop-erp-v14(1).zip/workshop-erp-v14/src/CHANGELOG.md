# تغییرات

## 0.14.0
- تاریخ سند برگشت دریافت اکنون صریحاً بر اساس منطقه زمانی `Asia/Tehran` محاسبه می‌شود و به timezone سرور PostgreSQL وابسته نیست.
- برای مسیر ساخت مالک اولیه، محدودیت ۵ تلاش در هر ۱۵ دقیقه به‌ازای IP اضافه شد؛ پاسخ محدودیت HTTP 429 و هدر `Retry-After` دارد.
- نسخه health و شماره نسخه بسته‌ها به ۰.۱۴.۰ ارتقا یافت.
- نشست HttpOnly، rate limit ورود، مدیریت کاربران، دسترسی‌های ریزدانه، حسابداری کامل، idempotency fingerprint و تست‌های عملی همچنان باز هستند.

## 0.7.0
- ثبت و مشاهده هزینه‌ها با سند حسابداری خودکار.
- ثبت و مشاهده انتقال وجه بین حساب‌های صندوق و بانک.
- افزودن حساب بانکی جدید با موجودی افتتاحیه صفر.
- برگشت دریافت با ثبت دلیل، سند معکوس و محاسبه مجدد وضعیت فاکتور.
- افزودن migration شماره ۰۰۰۵ و دسته‌های اولیه هزینه.
- به‌روزرسانی صفحات فارسی هزینه‌ها و انتقال وجه.

## 0.8.0
- Added warehouse and product master-data APIs and Persian UI.
- Added inventory summary and stock movement history.
- Added transactional stock IN/OUT/opening/adjustment recording with per-item advisory locking, insufficient-stock prevention and idempotency keys.
- Added immutable stock movement ledger trigger and supporting indexes/constraints.
- Production workflow and automatic costing remain future work.

## 0.9.0
- Added production orders, standard workshop steps and step activity logs.
- Added transactional material consumption with stock locking, quantity validation and unit-cost capture.
- Added human-confirmed production output with inventory posting and order quantity guard.
- Added tracked material/direct expense cost summary per production order.


## Version 0.10.0
- Added owner-controlled target profit per scarf in the website settings (default 200,000 toman).
- Only the OWNER role can change the amount; other roles cannot access the owner settings navigation or update the API setting.
- Production orders now display the target profit per scarf and indicative target sale price (tracked unit cost + owner-set target profit).
- The target profit is a pricing target, not a claim of realized accounting profit.


## 0.11.0
- افزودن API صورت‌حساب مشتری شامل فاکتورها، دریافت‌ها، جمع بدهی و مانده.
- نمایش پرونده مالی مشتری با انتخاب نام او از فهرست مشتریان.
- تفکیک دریافت جاری، تاریخی و افتتاحیه؛ حذف دریافت‌های برگشت‌خورده از محاسبات.
- ثبت مشاهده صورت‌حساب در audit log.
- حقوق و دستمزد همچنان خارج از دامنه نسخه فعلی است.


## 0.12.0
- Added customer-statement payment workflow against outstanding finalized invoices.
- Added account, amount, date, and payment-method selection.
- Uses atomic payment API validation, allocation, journal posting, audit log, and idempotency.
- Refreshes customer statement and financial summary after receipt.
- Payroll remains out of scope.
