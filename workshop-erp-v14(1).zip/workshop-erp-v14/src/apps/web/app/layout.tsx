import type { Metadata, Viewport } from 'next';
import './globals.css';
export const metadata: Metadata = { title: 'مدیریت کارگاه | Workshop ERP', description: 'سامانه مدیریت کارگاه رنگرزی', manifest: '/manifest.webmanifest' };
export const viewport: Viewport = { themeColor: '#172b4d', width: 'device-width', initialScale: 1 };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="fa" dir="rtl"><body>{children}</body></html>; }
