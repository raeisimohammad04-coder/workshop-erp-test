import { createServer, IncomingMessage, ServerResponse } from 'node:http';
import { randomBytes, randomUUID, scrypt as scryptCb, timingSafeEqual, createHmac } from 'node:crypto';
import { promisify } from 'node:util';
import { Pool } from 'pg';

const scrypt = promisify(scryptCb);
const pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 10 });
const PORT = Number(process.env.API_PORT || 4000);
const AUTH_SECRET = process.env.AUTH_SECRET || '';
const SETUP_TOKEN = process.env.SETUP_TOKEN || '';
const SESSION_DAYS = 7;
const SETUP_RATE_WINDOW_MS = 15 * 60 * 1000;
const SETUP_RATE_MAX_ATTEMPTS = 5;
const setupAttempts = new Map<string, { count: number; resetAt: number }>();
function setupRateLimitKey(req: IncomingMessage) { return req.socket.remoteAddress || 'unknown'; }
function checkSetupRateLimit(req: IncomingMessage) {
  const now = Date.now(); const key = setupRateLimitKey(req);
  for (const [ip, state] of setupAttempts) if (state.resetAt <= now) setupAttempts.delete(ip);
  const current = setupAttempts.get(key);
  if (!current || current.resetAt <= now) { setupAttempts.set(key, { count: 1, resetAt: now + SETUP_RATE_WINDOW_MS }); return { allowed: true, retryAfter: 0 }; }
  current.count += 1;
  return { allowed: current.count <= SETUP_RATE_MAX_ATTEMPTS, retryAfter: Math.max(1, Math.ceil((current.resetAt - now) / 1000)) };
}

type User = { id: string; full_name: string; phone: string; roles: string[] };
function send(res: ServerResponse, status: number, data: unknown) {
  res.writeHead(status, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store', 'x-content-type-options': 'nosniff' });
  res.end(JSON.stringify(data));
}
async function body(req: IncomingMessage): Promise<any> {
  const chunks: Buffer[] = []; let byteLength = 0;
  for await (const chunk of req) {
    const part = Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk);
    byteLength += part.length;
    if (byteLength > 1_000_000) throw new Error('BODY_TOO_LARGE');
    chunks.push(part);
  }
  const raw = Buffer.concat(chunks).toString('utf8');
  try { return raw ? JSON.parse(raw) : {}; } catch { throw new Error('INVALID_JSON'); }
}
function hashToken(token: string) { return createHmac('sha256', AUTH_SECRET).update(token).digest('hex'); }
function secretMatches(provided: string, expected: string) { const a=Buffer.from(provided); const b=Buffer.from(expected); return a.length===b.length && timingSafeEqual(a,b); }
async function passwordHash(password: string) {
  const salt = randomBytes(16).toString('hex');
  const key = await scrypt(password, salt, 64) as Buffer;
  return `scrypt$${salt}$${key.toString('hex')}`;
}
async function verifyPassword(password: string, stored: string) {
  const [scheme, salt, hex] = stored.split('$'); if (scheme !== 'scrypt' || !salt || !hex) return false;
  const expected = Buffer.from(hex, 'hex'); const actual = await scrypt(password, salt, expected.length) as Buffer;
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}
async function currentUser(req: IncomingMessage): Promise<User | null> {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, ''); if (!token) return null;
  const result = await pool.query(`SELECT u.id,u.full_name,u.phone,COALESCE(array_agg(r.code) FILTER (WHERE r.code IS NOT NULL),'{}') roles
    FROM sessions s JOIN users u ON u.id=s.user_id LEFT JOIN user_roles ur ON ur.user_id=u.id LEFT JOIN roles r ON r.id=ur.role_id
    WHERE s.token_hash=$1 AND s.revoked_at IS NULL AND s.expires_at>now() AND u.is_active=true GROUP BY u.id`, [hashToken(token)]);
  return result.rows[0] || null;
}
async function audit(userId: string, action: string, entity: string, entityId?: string) {
  await pool.query('INSERT INTO audit_logs(user_id,action,entity_type,entity_id) VALUES($1,$2,$3,$4)', [userId, action, entity, entityId || null]);
}

async function postJournal(client: import('pg').PoolClient, userId: string, entryDate: string, description: string, sourceType: string, sourceId: string, lines: Array<{code:string; debit:number; credit:number; financialAccountId?:string}>) {
  const totalDebit = lines.reduce((sum, line) => sum + line.debit, 0);
  const totalCredit = lines.reduce((sum, line) => sum + line.credit, 0);
  if (lines.length < 2 || totalDebit <= 0 || totalDebit !== totalCredit || lines.some(line => !Number.isSafeInteger(line.debit) || !Number.isSafeInteger(line.credit) || line.debit < 0 || line.credit < 0 || (line.debit > 0 && line.credit > 0))) {
    throw new Error('INVALID_JOURNAL_LINES');
  }
  const existing = await client.query("SELECT id FROM journal_entries WHERE source_type=$1 AND source_id=$2 AND status='POSTED'", [sourceType, sourceId]);
  if (existing.rowCount) return existing.rows[0].id;
  const entryId = randomUUID();
  const entryNumber = `JE-${Date.now()}-${randomBytes(3).toString('hex').toUpperCase()}`;
  await client.query(`INSERT INTO journal_entries(id,entry_number,entry_date,description,source_type,source_id,status,created_by)
    VALUES($1,$2,$3,$4,$5,$6,'DRAFT',$7)`, [entryId,entryNumber,entryDate,description,sourceType,sourceId,userId]);
  for (const line of lines) {
    const account = await client.query('SELECT id FROM accounting_accounts WHERE code=$1 AND is_active=true', [line.code]);
    if (!account.rowCount) throw new Error(`ACCOUNT_NOT_CONFIGURED_${line.code}`);
    await client.query(`INSERT INTO journal_lines(journal_entry_id,accounting_account_id,debit_amount,credit_amount,financial_account_id,description)
      VALUES($1,$2,$3,$4,$5,$6)`, [entryId,account.rows[0].id,line.debit,line.credit,line.financialAccountId || null,description]);
  }
  await client.query("UPDATE journal_entries SET status='POSTED',posted_by=$2 WHERE id=$1", [entryId,userId]);
  return entryId;
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
    if (req.method === 'GET' && url.pathname === '/api/health') {
      await pool.query('SELECT 1'); return send(res, 200, { status: 'ok', database: 'connected', service: 'workshop-erp-api', version: '0.14.0' });
    }
    if (req.method === 'GET' && url.pathname === '/api/setup/status') {
      const q = await pool.query('SELECT count(*)::int count FROM users'); return send(res, 200, { setupRequired: q.rows[0].count === 0 });
    }
    if (req.method === 'POST' && url.pathname === '/api/setup/owner') {
      const rate = checkSetupRateLimit(req);
      if (!rate.allowed) { res.setHeader('Retry-After', String(rate.retryAfter)); return send(res, 429, { error: 'تعداد تلاش‌های راه‌اندازی بیش از حد مجاز است. کمی بعد دوباره تلاش کنید.' }); }
      const input = await body(req); const fullName = String(input.fullName || '').trim(); const phone = String(input.phone || '').trim(); const password = String(input.password || '');
      if (!fullName || !/^\+?[0-9۰-۹٠-٩\- ]{8,20}$/.test(phone) || password.length < 12) return send(res, 400, { error: 'نام، شماره معتبر و رمز حداقل ۱۲ کاراکتری لازم است.' });
      if (SETUP_TOKEN.length < 32 || !secretMatches(String(req.headers['x-setup-token'] || ''), SETUP_TOKEN)) return send(res, 403, { error: 'توکن راه‌اندازی معتبر نیست؛ SETUP_TOKEN را در تنظیمات سرور بررسی کنید.' });
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        await client.query("SELECT pg_advisory_xact_lock(hashtext('workshop-erp-initial-owner'))");
        const count = await client.query('SELECT count(*)::int count FROM users'); if (count.rows[0].count !== 0) { await client.query('ROLLBACK'); return send(res, 409, { error: 'راه‌اندازی اولیه قبلاً انجام شده است.' }); }
        const userId = randomUUID();
        await client.query('INSERT INTO users(id,full_name,phone,password_hash) VALUES($1,$2,$3,$4)', [userId, fullName, phone, await passwordHash(password)]);
        const role = await client.query("SELECT id FROM roles WHERE code='OWNER'");
        await client.query('INSERT INTO user_roles(user_id,role_id) VALUES($1,$2)', [userId, role.rows[0].id]);
        await client.query('INSERT INTO audit_logs(user_id,action,entity_type,entity_id) VALUES($1,$2,$3,$1)', [userId, 'INITIAL_OWNER_CREATED', 'USER']);
        await client.query('COMMIT'); return send(res, 201, { created: true, message: 'حساب مالک ساخته شد. اکنون وارد شوید.' });
      } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/login') {
      const input = await body(req); const phone = String(input.phone || '').trim(); const password = String(input.password || '');
      const q = await pool.query('SELECT id,full_name,phone,password_hash FROM users WHERE phone=$1 AND is_active=true', [phone]);
      if (!q.rowCount || !(await verifyPassword(password, q.rows[0].password_hash))) return send(res, 401, { error: 'شماره تلفن یا رمز عبور صحیح نیست.' });
      const token = randomBytes(32).toString('base64url'); const expiry = new Date(Date.now() + SESSION_DAYS * 86400000);
      await pool.query('INSERT INTO sessions(user_id,token_hash,expires_at) VALUES($1,$2,$3)', [q.rows[0].id, hashToken(token), expiry]);
      await pool.query('UPDATE users SET last_login_at=now() WHERE id=$1', [q.rows[0].id]);
      await audit(q.rows[0].id, 'LOGIN', 'USER', q.rows[0].id);
      return send(res, 200, { token, expiresAt: expiry.toISOString(), user: { id: q.rows[0].id, fullName: q.rows[0].full_name, phone: q.rows[0].phone } });
    }
    if (req.method === 'POST' && url.pathname === '/api/auth/logout') {
      const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, ''); if (token) await pool.query('UPDATE sessions SET revoked_at=now() WHERE token_hash=$1', [hashToken(token)]);
      return send(res, 200, { loggedOut: true });
    }
    const user = await currentUser(req);
    if (req.method === 'GET' && url.pathname === '/api/auth/me') return user ? send(res, 200, { user }) : send(res, 401, { error: 'ابتدا وارد شوید.' });
    if (url.pathname === '/api/settings/profit' && req.method === 'GET') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      const q = await pool.query("SELECT setting_value FROM app_settings WHERE setting_key='profit_per_scarf_toman'");
      return send(res, 200, { profitPerScarfToman: Number(q.rows[0]?.setting_value ?? 200000), editable: user.roles.includes('OWNER') });
    }
    if (url.pathname === '/api/settings/profit' && req.method === 'PUT') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      if (!user.roles.includes('OWNER')) return send(res, 403, { error: 'فقط مالک اجازه تغییر سود هدف هر روسری را دارد.' });
      const input = await body(req); const amount = Number(input.profitPerScarfToman);
      if (!Number.isSafeInteger(amount) || amount < 0 || amount > 1000000000000) return send(res, 400, { error: 'مبلغ سود باید عدد صحیح و غیرمنفی به تومان باشد.' });
      await pool.query("INSERT INTO app_settings(setting_key,setting_value,updated_by,updated_at) VALUES('profit_per_scarf_toman',$1,$2,now()) ON CONFLICT(setting_key) DO UPDATE SET setting_value=EXCLUDED.setting_value,updated_by=EXCLUDED.updated_by,updated_at=now()", [String(amount), user.id]);
      await audit(user.id, 'PROFIT_PER_SCARF_UPDATED', 'APP_SETTING', 'profit_per_scarf_toman');
      return send(res, 200, { saved: true, profitPerScarfToman: amount });
    }
    if (url.pathname === '/api/customers' && req.method === 'GET') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      const term = String(url.searchParams.get('q') || '').trim();
      const q = await pool.query(`SELECT c.id,c.customer_code,c.full_name,c.phone,c.address,c.notes,c.created_at,
        COALESCE((SELECT sum(i.total_amount) FROM invoices i WHERE i.customer_id=c.id AND i.status IN ('FINALIZED','PARTIALLY_PAID','PAID')),0)::text total_invoiced,
        COALESCE((SELECT sum(pa.allocated_amount) FROM payment_allocations pa JOIN payments p ON p.id=pa.payment_id WHERE pa.invoice_id IN (SELECT id FROM invoices WHERE customer_id=c.id) AND p.reversed_at IS NULL),0)::text total_paid
        FROM customers c WHERE c.is_active=true AND ($1='' OR c.full_name ILIKE '%'||$1||'%' OR c.phone ILIKE '%'||$1||'%') ORDER BY c.full_name LIMIT 200`, [term]);
      return send(res, 200, { customers: q.rows });
    }
    if (url.pathname === '/api/customers' && req.method === 'POST') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      if (!user.roles.includes('OWNER') && !user.roles.includes('MANAGER')) return send(res, 403, { error: 'مجوز ثبت مشتری را ندارید.' });
      const input = await body(req); const fullName = String(input.fullName || '').trim(); const phone = String(input.phone || '').trim() || null;
      if (!fullName || fullName.length > 200) return send(res, 400, { error: 'نام مشتری الزامی و حداکثر ۲۰۰ حرف است.' });
      const q = await pool.query('INSERT INTO customers(customer_code,full_name,phone,address,notes) VALUES($1,$2,$3,$4,$5) RETURNING id,customer_code,full_name,phone,address,notes,created_at', [String(input.customerCode || '').trim() || null, fullName, phone, input.address || null, input.notes || null]);
      await audit(user.id, 'CUSTOMER_CREATED', 'CUSTOMER', q.rows[0].id); return send(res, 201, { customer: q.rows[0] });
    }
    const statementMatch = url.pathname.match(/^\/api\/customers\/([0-9a-f-]{36})\/statement$/i);
    if (statementMatch && req.method === 'GET') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      const customer = await pool.query('SELECT id,customer_code,full_name,phone,address,notes FROM customers WHERE id=$1 AND is_active=true', [statementMatch[1]]);
      if (!customer.rowCount) return send(res, 404, { error: 'مشتری پیدا نشد.' });
      const invoices = await pool.query(`SELECT i.id,i.invoice_number,i.issue_date,i.status,i.total_amount::text total_amount,
        COALESCE((SELECT sum(pa.allocated_amount) FROM payment_allocations pa JOIN payments p ON p.id=pa.payment_id WHERE pa.invoice_id=i.id AND p.reversed_at IS NULL),0)::text paid_amount
        FROM invoices i WHERE i.customer_id=$1 ORDER BY i.issue_date DESC,i.created_at DESC LIMIT 500`, [statementMatch[1]]);
      const payments = await pool.query(`SELECT p.id,p.payment_date,p.amount::text amount,p.method,p.source,p.reference_number,p.notes,
        COALESCE((SELECT sum(pa.allocated_amount) FROM payment_allocations pa WHERE pa.payment_id=p.id),0)::text allocated_amount
        FROM payments p WHERE p.customer_id=$1 AND p.reversed_at IS NULL ORDER BY p.payment_date DESC,p.recorded_at DESC LIMIT 500`, [statementMatch[1]]);
      const totals = await pool.query(`SELECT
        COALESCE((SELECT sum(total_amount) FROM invoices WHERE customer_id=$1 AND status IN ('FINALIZED','PARTIALLY_PAID','PAID')),0)::text invoiced,
        COALESCE((SELECT sum(pa.allocated_amount) FROM payment_allocations pa JOIN payments p ON p.id=pa.payment_id JOIN invoices i ON i.id=pa.invoice_id WHERE i.customer_id=$1 AND p.reversed_at IS NULL),0)::text paid,
        (COALESCE((SELECT sum(total_amount) FROM invoices WHERE customer_id=$1 AND status IN ('FINALIZED','PARTIALLY_PAID','PAID')),0)-
         COALESCE((SELECT sum(pa.allocated_amount) FROM payment_allocations pa JOIN payments p ON p.id=pa.payment_id JOIN invoices i ON i.id=pa.invoice_id WHERE i.customer_id=$1 AND p.reversed_at IS NULL),0))::text balance`, [statementMatch[1]]);
      await audit(user.id, 'CUSTOMER_STATEMENT_VIEWED', 'CUSTOMER', statementMatch[1]);
      return send(res, 200, { customer: customer.rows[0], invoices: invoices.rows, payments: payments.rows, totals: totals.rows[0] });
    }
    const match = url.pathname.match(/^\/api\/customers\/([0-9a-f-]{36})$/i);
    if (match && req.method === 'GET') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      const q = await pool.query('SELECT id,customer_code,full_name,phone,address,notes,created_at FROM customers WHERE id=$1 AND is_active=true', [match[1]]);
      return q.rowCount ? send(res, 200, { customer: q.rows[0] }) : send(res, 404, { error: 'مشتری پیدا نشد.' });
    }
    // Invoice endpoints: draft creation, finalization and read-only listing.
    if (req.method === 'GET' && url.pathname === '/api/invoices') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      const q = await pool.query(`SELECT i.id,i.invoice_number,i.issue_date,i.status,i.total_amount,i.created_at,c.full_name customer_name,
        COALESCE((SELECT sum(pa.allocated_amount) FROM payment_allocations pa JOIN payments p ON p.id=pa.payment_id WHERE pa.invoice_id=i.id AND p.reversed_at IS NULL),0)::text paid_amount
        FROM invoices i JOIN customers c ON c.id=i.customer_id ORDER BY i.created_at DESC LIMIT 200`);
      return send(res, 200, { invoices: q.rows });
    }
    if (req.method === 'POST' && url.pathname === '/api/invoices') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      if (!user.roles.some(r => ['OWNER','MANAGER'].includes(r))) return send(res, 403, { error: 'مجوز ایجاد فاکتور را ندارید.' });
      const input = await body(req); const customerId = String(input.customerId || '');
      const invoiceNumber = String(input.invoiceNumber || '').trim(); const issueDate = String(input.issueDate || '');
      const items = Array.isArray(input.items) ? input.items : [];
      if (!customerId.match(/^[0-9a-f-]{36}$/i) || !invoiceNumber || invoiceNumber.length > 50 || !/^\d{4}-\d{2}-\d{2}$/.test(issueDate) || !items.length || items.length > 100) return send(res, 400, { error: 'مشتری، شماره، تاریخ و حداقل یک ردیف فاکتور لازم است.' });
      let subtotal = 0;
      const cleanItems = [];
      for (const item of items) {
        const description = String(item.description || '').trim(); const unit = String(item.unit || 'عدد').trim();
        const quantity = Number(item.quantity); const unitPrice = Number(item.unitPrice); const discount = Number(item.discount || 0);
        if (!description || description.length > 500 || !unit || !Number.isFinite(quantity) || quantity <= 0 || !Number.isFinite(unitPrice) || !Number.isSafeInteger(unitPrice) || unitPrice < 0 || !Number.isSafeInteger(discount) || discount < 0) return send(res, 400, { error: 'اطلاعات یکی از ردیف‌های فاکتور معتبر نیست.' });
        const raw = Math.round(quantity * unitPrice); const lineTotal = raw - discount;
        if (!Number.isSafeInteger(raw) || lineTotal < 0 || !Number.isSafeInteger(subtotal + lineTotal)) return send(res, 400, { error: 'مبلغ فاکتور خارج از محدوده مجاز است.' });
        subtotal += raw; cleanItems.push({ description, unit, quantity, unitPrice, discount, lineTotal });
      }
      const invoiceDiscount = Number(input.discountAmount || 0);
      if (!Number.isSafeInteger(invoiceDiscount) || invoiceDiscount < 0 || invoiceDiscount > subtotal) return send(res, 400, { error: 'تخفیف فاکتور معتبر نیست.' });
      const itemDiscounts = cleanItems.reduce((a, x) => a + x.discount, 0);
      if (itemDiscounts + invoiceDiscount > subtotal) return send(res, 400, { error: 'مجموع تخفیف ردیف‌ها و تخفیف کل نمی‌تواند از مبلغ ناخالص فاکتور بیشتر باشد.' });
      const total = subtotal - itemDiscounts - invoiceDiscount;
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const customer = await client.query('SELECT id FROM customers WHERE id=$1 AND is_active=true', [customerId]);
        if (!customer.rowCount) { await client.query('ROLLBACK'); return send(res, 404, { error: 'مشتری پیدا نشد.' }); }
        const created = await client.query(`INSERT INTO invoices(invoice_number,customer_id,issue_date,subtotal,discount_amount,total_amount,notes,created_by)
          VALUES($1,$2,$3,$4,$5,$6,$7,$8) RETURNING id,invoice_number,customer_id,issue_date,status,subtotal,discount_amount,total_amount`, [invoiceNumber,customerId,issueDate,subtotal,itemDiscounts+invoiceDiscount,total,input.notes || null,user.id]);
        for (const x of cleanItems) await client.query(`INSERT INTO invoice_items(invoice_id,description,quantity,unit,unit_price,line_discount,line_total) VALUES($1,$2,$3,$4,$5,$6,$7)`, [created.rows[0].id,x.description,x.quantity,x.unit,x.unitPrice,x.discount,x.lineTotal]);
        await client.query('INSERT INTO audit_logs(user_id,action,entity_type,entity_id) VALUES($1,$2,$3,$4)', [user.id,'INVOICE_DRAFT_CREATED','INVOICE',created.rows[0].id]);
        await client.query('COMMIT'); return send(res, 201, { invoice: created.rows[0] });
      } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
    }
    const invoiceMatch = url.pathname.match(/^\/api\/invoices\/([0-9a-f-]{36})$/i);
    if (req.method === 'GET' && invoiceMatch) {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      const q = await pool.query(`SELECT i.*,c.full_name customer_name FROM invoices i JOIN customers c ON c.id=i.customer_id WHERE i.id=$1`, [invoiceMatch[1]]);
      if (!q.rowCount) return send(res, 404, { error: 'فاکتور پیدا نشد.' });
      const lines = await pool.query('SELECT id,description,quantity,unit,unit_price,line_discount,line_total FROM invoice_items WHERE invoice_id=$1 ORDER BY ctid', [invoiceMatch[1]]);
      return send(res, 200, { invoice: q.rows[0], items: lines.rows });
    }
    const finalizeMatch = url.pathname.match(/^\/api\/invoices\/([0-9a-f-]{36})\/finalize$/i);
    if (req.method === 'POST' && finalizeMatch) {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      if (!user.roles.some(r => ['OWNER','MANAGER'].includes(r))) return send(res, 403, { error: 'مجوز قطعی‌کردن فاکتور را ندارید.' });
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const inv = await client.query('SELECT id,status,total_amount,issue_date FROM invoices WHERE id=$1 FOR UPDATE', [finalizeMatch[1]]);
        if (!inv.rowCount) { await client.query('ROLLBACK'); return send(res, 404, { error: 'فاکتور پیدا نشد.' }); }
        if (inv.rows[0].status !== 'DRAFT') { await client.query('ROLLBACK'); return send(res, 409, { error: 'فقط فاکتور پیش‌نویس قابل قطعی‌شدن است.' }); }
        const count = await client.query('SELECT count(*)::int count FROM invoice_items WHERE invoice_id=$1', [finalizeMatch[1]]);
        if (!count.rows[0].count) { await client.query('ROLLBACK'); return send(res, 400, { error: 'فاکتور بدون ردیف قابل قطعی‌شدن نیست.' }); }
        const updated = await client.query(`UPDATE invoices SET status='FINALIZED',finalized_at=now(),finalized_by=$2,updated_at=now() WHERE id=$1 RETURNING id,invoice_number,status,total_amount,finalized_at`, [finalizeMatch[1],user.id]);
        await client.query('INSERT INTO invoice_status_history(invoice_id,old_status,new_status,changed_by) VALUES($1,$2,$3,$4)', [finalizeMatch[1],'DRAFT','FINALIZED',user.id]);
        if (Number(inv.rows[0].total_amount) > 0) {
          await postJournal(client,user.id,String(inv.rows[0].issue_date).slice(0,10),
            `ثبت فروش فاکتور ${updated.rows[0].invoice_number}`,'INVOICE',finalizeMatch[1],[
              {code:'1100',debit:Number(inv.rows[0].total_amount),credit:0},
              {code:'4000',debit:0,credit:Number(inv.rows[0].total_amount)}
            ]);
        }
        await client.query('INSERT INTO audit_logs(user_id,action,entity_type,entity_id) VALUES($1,$2,$3,$4)', [user.id,'INVOICE_FINALIZED','INVOICE',finalizeMatch[1]]);
        await client.query('COMMIT'); return send(res, 200, { invoice: updated.rows[0] });
      } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
    }
    if (req.method === 'GET' && url.pathname === '/api/financial-accounts') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      const q = await pool.query('SELECT id,name,type FROM financial_accounts WHERE is_active=true ORDER BY name');
      return send(res, 200, { accounts: q.rows });
    }
    if (req.method === 'POST' && url.pathname === '/api/payments') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      if (!user.roles.some(r => ['OWNER','MANAGER'].includes(r))) return send(res, 403, { error: 'مجوز ثبت دریافت را ندارید.' });
      const input = await body(req); const customerId = String(input.customerId || ''); const invoiceId = String(input.invoiceId || '');
      const accountId = String(input.financialAccountId || ''); const amount = Number(input.amount); const paymentDate = String(input.paymentDate || '');
      const method = String(input.method || 'CASH'); const idem = String(req.headers['idempotency-key'] || '').trim();
      if (![customerId,invoiceId,accountId].every(x => /^[0-9a-f-]{36}$/i.test(x)) || !Number.isSafeInteger(amount) || amount <= 0 || !/^\d{4}-\d{2}-\d{2}$/.test(paymentDate) || !idem || idem.length > 180) return send(res, 400, { error: 'مشتری، فاکتور، حساب، مبلغ، تاریخ و کلید یکتای درخواست لازم است.' });
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const existing = await client.query('SELECT response_reference FROM idempotency_keys WHERE key=$1 AND user_id=$2 AND operation=$3', [idem,user.id,'PAYMENT_CREATE']);
        if (existing.rowCount) { await client.query('ROLLBACK'); return send(res, 200, { paymentId: existing.rows[0].response_reference, duplicateRequest: true }); }
        const inv = await client.query('SELECT customer_id,total_amount,status FROM invoices WHERE id=$1 FOR UPDATE', [invoiceId]);
        if (!inv.rowCount || inv.rows[0].customer_id !== customerId || !['FINALIZED','PARTIALLY_PAID'].includes(inv.rows[0].status)) { await client.query('ROLLBACK'); return send(res, 400, { error: 'فاکتور برای دریافت معتبر نیست یا متعلق به این مشتری نیست.' }); }
        const acct = await client.query('SELECT id FROM financial_accounts WHERE id=$1 AND is_active=true', [accountId]);
        if (!acct.rowCount) { await client.query('ROLLBACK'); return send(res, 400, { error: 'حساب مالی معتبر نیست.' }); }
        const paid = await client.query(`SELECT COALESCE(sum(pa.allocated_amount),0)::bigint paid FROM payment_allocations pa JOIN payments p ON p.id=pa.payment_id WHERE pa.invoice_id=$1 AND p.reversed_at IS NULL`, [invoiceId]);
        if (amount > Number(inv.rows[0].total_amount) - Number(paid.rows[0].paid)) { await client.query('ROLLBACK'); return send(res, 409, { error: 'مبلغ دریافت از مانده فاکتور بیشتر است.' }); }
        const payment = await client.query(`INSERT INTO payments(customer_id,financial_account_id,amount,payment_date,method,source,created_by) VALUES($1,$2,$3,$4,$5,'CURRENT',$6) RETURNING id,amount,payment_date`, [customerId,accountId,amount,paymentDate,method,user.id]);
        await client.query('INSERT INTO payment_allocations(payment_id,invoice_id,allocated_amount) VALUES($1,$2,$3)', [payment.rows[0].id,invoiceId,amount]);
        const newPaid = Number(paid.rows[0].paid) + amount; const newStatus = newPaid === Number(inv.rows[0].total_amount) ? 'PAID' : 'PARTIALLY_PAID';
        await client.query('UPDATE invoices SET status=$2,updated_at=now() WHERE id=$1', [invoiceId,newStatus]);
        await client.query('INSERT INTO idempotency_keys(key,user_id,operation,response_reference,expires_at) VALUES($1,$2,$3,$4,now()+interval \'30 days\')', [idem,user.id,'PAYMENT_CREATE',payment.rows[0].id]);
        await postJournal(client,user.id,paymentDate,`دریافت از مشتری بابت فاکتور ${invoiceId}`,'PAYMENT',payment.rows[0].id,[
          {code:'1010',debit:amount,credit:0,financialAccountId:accountId},
          {code:'1100',debit:0,credit:amount}
        ]);
        await client.query('INSERT INTO audit_logs(user_id,action,entity_type,entity_id) VALUES($1,$2,$3,$4)', [user.id,'PAYMENT_CREATED','PAYMENT',payment.rows[0].id]);
        await client.query('COMMIT'); return send(res, 201, { payment: payment.rows[0], invoiceStatus: newStatus });
      } catch (e) { await client.query('ROLLBACK'); throw e; } finally { client.release(); }
    }
    if (req.method === 'POST' && url.pathname === '/api/financial-accounts') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      if (!user.roles.some(r=>['OWNER','MANAGER'].includes(r))) return send(res,403,{error:'مجوز ایجاد حساب مالی را ندارید.'});
      const input=await body(req);const name=String(input.name||'').trim();const type=String(input.type||'BANK');
      if(name.length<2||name.length>120||!['BANK','CASH'].includes(type))return send(res,400,{error:'نام حساب و نوع معتبر لازم است.'});
      const exists=await pool.query('SELECT id FROM financial_accounts WHERE lower(name)=lower($1) AND is_active=true',[name]);
      if(exists.rowCount)return send(res,409,{error:'حسابی با این نام از قبل وجود دارد.'});
      const result=await pool.query('INSERT INTO financial_accounts(name,type,opening_balance) VALUES($1,$2,0) RETURNING id,name,type',[name,type]);
      await audit(user.id,'FINANCIAL_ACCOUNT_CREATED','FINANCIAL_ACCOUNT',result.rows[0].id);
      return send(res,201,{account:result.rows[0]});
    }
    if (req.method === 'GET' && url.pathname === '/api/expense-categories') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      const q = await pool.query('SELECT id,name FROM expense_categories WHERE is_active=true ORDER BY name');
      return send(res, 200, { categories: q.rows });
    }
    if (req.method === 'GET' && url.pathname === '/api/expenses') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      if (!user.roles.some(r => ['OWNER','MANAGER'].includes(r))) return send(res, 403, { error: 'مجوز مشاهده هزینه‌ها را ندارید.' });
      const q = await pool.query(`SELECT e.id,e.amount::text,e.expense_date,e.description,e.reference_number,e.reversed_at,
        c.name category_name,a.name account_name FROM expenses e JOIN expense_categories c ON c.id=e.category_id
        JOIN financial_accounts a ON a.id=e.financial_account_id ORDER BY e.expense_date DESC,e.created_at DESC LIMIT 200`);
      return send(res, 200, { expenses: q.rows });
    }
    if (req.method === 'POST' && url.pathname === '/api/expenses') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      if (!user.roles.some(r => ['OWNER','MANAGER'].includes(r))) return send(res, 403, { error: 'مجوز ثبت هزینه را ندارید.' });
      const input = await body(req); const categoryId=String(input.categoryId||''); const accountId=String(input.financialAccountId||'');
      const amount=Number(input.amount); const expenseDate=String(input.expenseDate||''); const description=String(input.description||'').trim(); const productionOrderId=String(input.productionOrderId||'').trim()||null;
      const idem=String(req.headers['idempotency-key']||'').trim();
      if (![categoryId,accountId].every(x=>/^[0-9a-f-]{36}$/i.test(x)) || (productionOrderId&&!/^[0-9a-f-]{36}$/i.test(productionOrderId)) || !Number.isSafeInteger(amount) || amount<=0 || !/^\d{4}-\d{2}-\d{2}$/.test(expenseDate) || !description || description.length>500 || !idem || idem.length>180)
        return send(res,400,{error:'دسته هزینه، حساب، مبلغ صحیح، تاریخ، شرح و کلید یکتای درخواست لازم است.'});
      const client=await pool.connect();
      try {
        await client.query('BEGIN');
        const existing=await client.query("SELECT response_reference FROM idempotency_keys WHERE key=$1 AND user_id=$2 AND operation='EXPENSE_CREATE'",[idem,user.id]);
        if(existing.rowCount){await client.query('ROLLBACK');return send(res,200,{expenseId:existing.rows[0].response_reference,duplicateRequest:true});}
        const cat=await client.query('SELECT id FROM expense_categories WHERE id=$1 AND is_active=true',[categoryId]);
        const acct=await client.query('SELECT id FROM financial_accounts WHERE id=$1 AND is_active=true',[accountId]);
        if(!cat.rowCount||!acct.rowCount){await client.query('ROLLBACK');return send(res,400,{error:'دسته هزینه یا حساب مالی معتبر نیست.'});}
        if(productionOrderId){const po=await client.query("SELECT id FROM production_orders WHERE id=$1 AND status<>'CANCELLED'",[productionOrderId]);if(!po.rowCount){await client.query('ROLLBACK');return send(res,400,{error:'سفارش تولید برای اتصال هزینه معتبر نیست.'});}}
        const result=await client.query(`INSERT INTO expenses(category_id,financial_account_id,amount,expense_date,description,created_by,production_order_id)
          VALUES($1,$2,$3,$4,$5,$6,$7) RETURNING id,amount::text,expense_date,description,production_order_id`,[categoryId,accountId,amount,expenseDate,description,user.id,productionOrderId]);
        const expense=result.rows[0];
        await postJournal(client,user.id,expenseDate,`ثبت هزینه: ${description}`,'EXPENSE',expense.id,[
          {code:'5000',debit:amount,credit:0}, {code:'1010',debit:0,credit:amount,financialAccountId:accountId}
        ]);
        await client.query("INSERT INTO idempotency_keys(key,user_id,operation,response_reference,expires_at) VALUES($1,$2,'EXPENSE_CREATE',$3,now()+interval '30 days')",[idem,user.id,expense.id]);
        await client.query('INSERT INTO audit_logs(user_id,action,entity_type,entity_id) VALUES($1,$2,$3,$4)',[user.id,'EXPENSE_CREATED','EXPENSE',expense.id]);
        await client.query('COMMIT'); return send(res,201,{expense});
      } catch(e){await client.query('ROLLBACK');throw e;} finally{client.release();}
    }
    if (req.method === 'GET' && url.pathname === '/api/account-transfers') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      if (!user.roles.some(r=>['OWNER','MANAGER'].includes(r))) return send(res,403,{error:'مجوز مشاهده انتقال‌ها را ندارید.'});
      const q=await pool.query(`SELECT t.id,t.amount::text,t.transfer_date,t.reference_number,t.notes,
        f.name from_account_name,to_a.name to_account_name FROM account_transfers t
        JOIN financial_accounts f ON f.id=t.from_account_id JOIN financial_accounts to_a ON to_a.id=t.to_account_id
        ORDER BY t.transfer_date DESC,t.created_at DESC LIMIT 200`);
      return send(res,200,{transfers:q.rows});
    }
    if (req.method === 'POST' && url.pathname === '/api/account-transfers') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      if (!user.roles.some(r=>['OWNER','MANAGER'].includes(r))) return send(res,403,{error:'مجوز انتقال وجه را ندارید.'});
      const input=await body(req); const from=String(input.fromAccountId||''); const to=String(input.toAccountId||'');
      const amount=Number(input.amount); const date=String(input.transferDate||''); const notes=String(input.notes||'').trim();
      const idem=String(req.headers['idempotency-key']||'').trim();
      if (![from,to].every(x=>/^[0-9a-f-]{36}$/i.test(x))||from===to||!Number.isSafeInteger(amount)||amount<=0||!/^\d{4}-\d{2}-\d{2}$/.test(date)||!idem||idem.length>180)
        return send(res,400,{error:'حساب مبدأ، مقصد متفاوت، مبلغ، تاریخ و کلید یکتای درخواست لازم است.'});
      const client=await pool.connect();
      try{
        await client.query('BEGIN');
        const existing=await client.query("SELECT response_reference FROM idempotency_keys WHERE key=$1 AND user_id=$2 AND operation='TRANSFER_CREATE'",[idem,user.id]);
        if(existing.rowCount){await client.query('ROLLBACK');return send(res,200,{transferId:existing.rows[0].response_reference,duplicateRequest:true});}
        const accts=await client.query('SELECT id FROM financial_accounts WHERE id=ANY($1::uuid[]) AND is_active=true ORDER BY id FOR UPDATE',[[from,to]]);
        if(accts.rowCount!==2){await client.query('ROLLBACK');return send(res,400,{error:'هر دو حساب باید فعال و معتبر باشند.'});}
        const result=await client.query(`INSERT INTO account_transfers(from_account_id,to_account_id,amount,transfer_date,notes,created_by)
          VALUES($1,$2,$3,$4,$5,$6) RETURNING id,amount::text,transfer_date`,[from,to,amount,date,notes||null,user.id]);
        const transfer=result.rows[0];
        await postJournal(client,user.id,date,'انتقال وجه بین حساب‌های کارگاه','ACCOUNT_TRANSFER',transfer.id,[
          {code:'1010',debit:amount,credit:0,financialAccountId:to},
          {code:'1010',debit:0,credit:amount,financialAccountId:from}
        ]);
        await client.query("INSERT INTO idempotency_keys(key,user_id,operation,response_reference,expires_at) VALUES($1,$2,'TRANSFER_CREATE',$3,now()+interval '30 days')",[idem,user.id,transfer.id]);
        await client.query('INSERT INTO audit_logs(user_id,action,entity_type,entity_id) VALUES($1,$2,$3,$4)',[user.id,'ACCOUNT_TRANSFER_CREATED','ACCOUNT_TRANSFER',transfer.id]);
        await client.query('COMMIT');return send(res,201,{transfer});
      }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
    }
    const reversePaymentMatch=url.pathname.match(/^\/api\/payments\/([0-9a-f-]{36})\/reverse$/i);
    if(req.method==='POST'&&reversePaymentMatch){
      if(!user)return send(res,401,{error:'ابتدا وارد شوید.'});
      if(!user.roles.some(r=>['OWNER','MANAGER'].includes(r)))return send(res,403,{error:'مجوز برگشت دریافت را ندارید.'});
      const input=await body(req);const reason=String(input.reason||'').trim();
      if(reason.length<3||reason.length>500)return send(res,400,{error:'دلیل برگشت باید بین ۳ تا ۵۰۰ نویسه باشد.'});
      const client=await pool.connect();
      try{
        await client.query('BEGIN');
        const p=await client.query('SELECT id,amount,customer_id,reversed_at,payment_date FROM payments WHERE id=$1 FOR UPDATE',[reversePaymentMatch[1]]);
        if(!p.rowCount){await client.query('ROLLBACK');return send(res,404,{error:'دریافت پیدا نشد.'});}
        if(p.rows[0].reversed_at){await client.query('ROLLBACK');return send(res,409,{error:'این دریافت قبلاً برگشت خورده است.'});}
        const allocations=await client.query('SELECT invoice_id FROM payment_allocations WHERE payment_id=$1 ORDER BY invoice_id',[p.rows[0].id]);
        if (allocations.rowCount) await client.query('SELECT id FROM invoices WHERE id=ANY($1::uuid[]) ORDER BY id FOR UPDATE',[allocations.rows.map((a:any)=>a.invoice_id)]);
        const original=await client.query("SELECT id,entry_date FROM journal_entries WHERE source_type='PAYMENT' AND source_id=$1 AND status='POSTED'",[p.rows[0].id]);
        if(!original.rowCount){await client.query('ROLLBACK');return send(res,409,{error:'سند حسابداری دریافت پیدا نشد؛ برگشت خودکار ممکن نیست.'});}
        const lines=await client.query(`SELECT aa.code,jl.debit_amount::text,jl.credit_amount::text,jl.financial_account_id
          FROM journal_lines jl JOIN accounting_accounts aa ON aa.id=jl.accounting_account_id WHERE jl.journal_entry_id=$1`,[original.rows[0].id]);
        const reversalId=randomUUID();
        const reversalDate=await client.query("SELECT (CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Tehran')::date::text reversal_date");
        await postJournal(client,user.id,reversalDate.rows[0].reversal_date,`برگشت دریافت: ${reason}`,'PAYMENT_REVERSAL',p.rows[0].id,
          lines.rows.map((l:any)=>({code:l.code,debit:Number(l.credit_amount),credit:Number(l.debit_amount),financialAccountId:l.financial_account_id||undefined})));
        await client.query('UPDATE payments SET reversed_at=now() WHERE id=$1',[p.rows[0].id]);
        for(const a of allocations.rows){
          const paid=await client.query(`SELECT COALESCE(sum(pa.allocated_amount),0)::bigint paid FROM payment_allocations pa JOIN payments pm ON pm.id=pa.payment_id WHERE pa.invoice_id=$1 AND pm.reversed_at IS NULL`,[a.invoice_id]);
          const inv=await client.query('SELECT total_amount,status FROM invoices WHERE id=$1 FOR UPDATE',[a.invoice_id]);
          if(inv.rowCount&&['PAID','PARTIALLY_PAID'].includes(inv.rows[0].status)){
            const newStatus=Number(paid.rows[0].paid)===0?'FINALIZED':Number(paid.rows[0].paid)>=Number(inv.rows[0].total_amount)?'PAID':'PARTIALLY_PAID';
            await client.query('UPDATE invoices SET status=$2,updated_at=now() WHERE id=$1',[a.invoice_id,newStatus]);
            await client.query('INSERT INTO invoice_status_history(invoice_id,old_status,new_status,reason,changed_by) VALUES($1,$2,$3,$4,$5)',[a.invoice_id,inv.rows[0].status,newStatus,`برگشت دریافت: ${reason}`,user.id]);
          }
        }
        await client.query('INSERT INTO audit_logs(user_id,action,entity_type,entity_id) VALUES($1,$2,$3,$4)',[user.id,'PAYMENT_REVERSED','PAYMENT',p.rows[0].id]);
        await client.query('COMMIT');return send(res,200,{reversed:true,paymentId:p.rows[0].id});
      }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
    }
    if (req.method === 'GET' && url.pathname === '/api/warehouses') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      const q=await pool.query('SELECT id,name,description,is_active FROM warehouses WHERE is_active=true ORDER BY name');
      return send(res,200,{warehouses:q.rows});
    }
    if (req.method === 'POST' && url.pathname === '/api/warehouses') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      if (!user.roles.some(r=>['OWNER','MANAGER'].includes(r))) return send(res,403,{error:'مجوز ایجاد انبار را ندارید.'});
      const input=await body(req);const name=String(input.name||'').trim();const description=String(input.description||'').trim()||null;
      if(name.length<2||name.length>120)return send(res,400,{error:'نام انبار باید بین ۲ تا ۱۲۰ حرف باشد.'});
      const q=await pool.query('INSERT INTO warehouses(name,description) VALUES($1,$2) RETURNING id,name,description',[name,description]);
      await audit(user.id,'WAREHOUSE_CREATED','WAREHOUSE',q.rows[0].id);return send(res,201,{warehouse:q.rows[0]});
    }
    if (req.method === 'GET' && url.pathname === '/api/products') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      const q=await pool.query('SELECT id,sku,name,category,unit,minimum_stock,is_active FROM products WHERE is_active=true ORDER BY name');
      return send(res,200,{products:q.rows});
    }
    if (req.method === 'POST' && url.pathname === '/api/products') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      if (!user.roles.some(r=>['OWNER','MANAGER'].includes(r))) return send(res,403,{error:'مجوز تعریف کالا را ندارید.'});
      const input=await body(req);const name=String(input.name||'').trim();const sku=String(input.sku||'').trim()||null;const category=String(input.category||'').trim()||null;const unit=String(input.unit||'عدد').trim();const minimum=Number(input.minimumStock||0);
      if(name.length<2||name.length>180||unit.length<1||unit.length>30||!Number.isFinite(minimum)||minimum<0)return send(res,400,{error:'نام، واحد و حداقل موجودی معتبر لازم است.'});
      const q=await pool.query('INSERT INTO products(sku,name,category,unit,minimum_stock) VALUES($1,$2,$3,$4,$5) RETURNING id,sku,name,category,unit,minimum_stock',[sku,name,category,unit,minimum]);
      await audit(user.id,'PRODUCT_CREATED','PRODUCT',q.rows[0].id);return send(res,201,{product:q.rows[0]});
    }
    if (req.method === 'GET' && url.pathname === '/api/inventory/summary') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      const q=await pool.query(`SELECT w.id warehouse_id,w.name warehouse_name,p.id product_id,p.sku,p.name product_name,p.category,p.unit,p.minimum_stock,
        COALESCE(sum(sm.quantity*sm.direction),0)::numeric(14,3)::text quantity
        FROM warehouses w CROSS JOIN products p LEFT JOIN stock_movements sm ON sm.warehouse_id=w.id AND sm.product_id=p.id
        WHERE w.is_active=true AND p.is_active=true GROUP BY w.id,w.name,p.id ORDER BY w.name,p.name`);
      return send(res,200,{items:q.rows.map((x:any)=>({...x,quantity:Number(x.quantity),minimum_stock:Number(x.minimum_stock),low_stock:Number(x.quantity)<Number(x.minimum_stock)}))});
    }
    if (req.method === 'GET' && url.pathname === '/api/stock-movements') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      const q=await pool.query(`SELECT sm.id,sm.movement_type,sm.quantity::text,sm.direction,sm.movement_date,sm.notes,w.name warehouse_name,p.name product_name,p.unit
        FROM stock_movements sm JOIN warehouses w ON w.id=sm.warehouse_id JOIN products p ON p.id=sm.product_id
        ORDER BY sm.movement_date DESC,sm.created_at DESC LIMIT 200`);
      return send(res,200,{movements:q.rows});
    }
    if (req.method === 'POST' && url.pathname === '/api/stock-movements') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      if (!user.roles.some(r=>['OWNER','MANAGER'].includes(r))) return send(res,403,{error:'مجوز ثبت گردش انبار را ندارید.'});
      const input=await body(req);const warehouseId=String(input.warehouseId||'');const productId=String(input.productId||'');const quantity=Number(input.quantity);const movementDate=String(input.movementDate||'');const movementType=String(input.movementType||'IN');const notes=String(input.notes||'').trim()||null;const idem=String(req.headers['idempotency-key']||'').trim();
      if(!/^[0-9a-f-]{36}$/i.test(warehouseId)||!/^[0-9a-f-]{36}$/i.test(productId)||!Number.isFinite(quantity)||quantity<=0||quantity>999999999||!/^\d{4}-\d{2}-\d{2}$/.test(movementDate)||!['OPENING','IN','OUT','ADJUSTMENT'].includes(movementType)||!idem||idem.length>180)return send(res,400,{error:'انبار، کالا، مقدار مثبت، تاریخ، نوع گردش و کلید یکتا لازم است.'});
      const direction=movementType==='OUT'?-1:1;const client=await pool.connect();
      try{
        await client.query('BEGIN');
        await client.query('SELECT pg_advisory_xact_lock(hashtext($1))',['stock-idem:'+idem]);
        const existing=await client.query('SELECT id FROM stock_movements WHERE idempotency_key=$1',[idem]);
        if(existing.rowCount){await client.query('ROLLBACK');return send(res,200,{movementId:existing.rows[0].id,duplicateRequest:true});}
        const refs=await client.query('SELECT w.id FROM warehouses w CROSS JOIN products p WHERE w.id=$1 AND p.id=$2 AND w.is_active=true AND p.is_active=true',[warehouseId,productId]);
        if(!refs.rowCount){await client.query('ROLLBACK');return send(res,400,{error:'انبار یا کالای انتخاب‌شده معتبر نیست.'});}
        await client.query('SELECT pg_advisory_xact_lock(hashtext($1))',[warehouseId+':'+productId]);
        const balance=await client.query('SELECT COALESCE(sum(quantity*direction),0)::numeric(14,3) balance FROM stock_movements WHERE warehouse_id=$1 AND product_id=$2',[warehouseId,productId]);
        if(direction<0&&Number(balance.rows[0].balance)<quantity){await client.query('ROLLBACK');return send(res,409,{error:`موجودی کافی نیست. موجودی فعلی: ${balance.rows[0].balance}`});}
        const q=await client.query(`INSERT INTO stock_movements(warehouse_id,product_id,movement_type,quantity,direction,movement_date,notes,created_by,idempotency_key)
          VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9) RETURNING id,quantity::text,movement_type,direction,movement_date`,[warehouseId,productId,movementType,quantity,direction,movementDate,notes,user.id,idem]);
        await client.query('INSERT INTO audit_logs(user_id,action,entity_type,entity_id) VALUES($1,$2,$3,$4)',[user.id,'STOCK_MOVEMENT_CREATED','STOCK_MOVEMENT',q.rows[0].id]);
        await client.query('COMMIT');return send(res,201,{movement:q.rows[0],newBalance:Number(balance.rows[0].balance)+(quantity*direction)});
      }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
    }
    if (req.method === 'GET' && url.pathname === '/api/production-steps') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      const q=await pool.query('SELECT id,name,sort_order FROM production_steps WHERE is_active=true ORDER BY sort_order,name');
      return send(res,200,{steps:q.rows});
    }
    if (req.method === 'GET' && url.pathname === '/api/production-orders') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      const setting=await pool.query("SELECT setting_value FROM app_settings WHERE setting_key='profit_per_scarf_toman'"); const targetProfit=Number(setting.rows[0]?.setting_value ?? 200000);
      const q=await pool.query(`SELECT po.id,po.order_number,po.title,po.quantity::text,po.produced_quantity::text,po.status,
        po.planned_start_date,po.planned_end_date,po.notes,c.full_name customer_name,
        COALESCE((SELECT sum(pc.total_cost_toman) FROM production_consumptions pc WHERE pc.production_order_id=po.id),0)::text material_cost,
        COALESCE((SELECT sum(e.amount) FROM expenses e WHERE e.production_order_id=po.id AND e.reversed_at IS NULL),0)::text direct_expenses
        FROM production_orders po LEFT JOIN customers c ON c.id=po.customer_id ORDER BY po.created_at DESC LIMIT 200`);
      const ids=q.rows.map((x:any)=>x.id);
      let logs:any[]=[]; if(ids.length){const l=await pool.query(`SELECT l.id,l.production_order_id,l.status,l.started_at,l.completed_at,l.notes,s.name step_name,s.sort_order FROM production_step_logs l JOIN production_steps s ON s.id=l.production_step_id WHERE l.production_order_id=ANY($1::uuid[]) ORDER BY s.sort_order,l.created_at DESC`,[ids]);logs=l.rows;}
      return send(res,200,{orders:q.rows.map((x:any)=>({...x,quantity:Number(x.quantity),produced_quantity:Number(x.produced_quantity),material_cost:Number(x.material_cost),direct_expenses:Number(x.direct_expenses),total_tracked_cost:Number(x.material_cost)+Number(x.direct_expenses),unit_cost:Number(x.produced_quantity)>0?Math.round((Number(x.material_cost)+Number(x.direct_expenses))/Number(x.produced_quantity)):null,target_profit_per_scarf_toman:targetProfit,target_sale_price_per_scarf_toman:Number(x.produced_quantity)>0?Math.round((Number(x.material_cost)+Number(x.direct_expenses))/Number(x.produced_quantity))+targetProfit:null,steps:logs.filter((l:any)=>l.production_order_id===x.id)}))});
    }
    if (req.method === 'POST' && url.pathname === '/api/production-orders') {
      if (!user) return send(res,401,{error:'ابتدا وارد شوید.'});
      if (!user.roles.some(r=>['OWNER','MANAGER'].includes(r))) return send(res,403,{error:'مجوز ایجاد سفارش تولید را ندارید.'});
      const input=await body(req); const orderNumber=String(input.orderNumber||'').trim(); const title=String(input.title||'').trim();
      const quantity=Number(input.quantity); const customerId=String(input.customerId||'').trim()||null;
      const start=String(input.plannedStartDate||'').trim()||null; const end=String(input.plannedEndDate||'').trim()||null; const notes=String(input.notes||'').trim()||null;
      if(orderNumber.length<2||orderNumber.length>50||title.length<2||title.length>180||!Number.isFinite(quantity)||quantity<=0||quantity>999999999|| (customerId&&!/^[0-9a-f-]{36}$/i.test(customerId)) || (start&&!/^\d{4}-\d{2}-\d{2}$/.test(start)) || (end&&!/^\d{4}-\d{2}-\d{2}$/.test(end)) || (start&&end&&start>end)) return send(res,400,{error:'شماره، عنوان، تعداد مثبت و تاریخ‌های معتبر لازم است.'});
      const client=await pool.connect(); try { await client.query('BEGIN');
        if(customerId){const c=await client.query('SELECT id FROM customers WHERE id=$1 AND is_active=true',[customerId]);if(!c.rowCount){await client.query('ROLLBACK');return send(res,400,{error:'مشتری انتخاب‌شده معتبر نیست.'});}}
        const q=await client.query(`INSERT INTO production_orders(order_number,customer_id,title,quantity,status,planned_start_date,planned_end_date,notes,created_by) VALUES($1,$2,$3,$4,'PENDING',$5,$6,$7,$8) RETURNING id,order_number,title,quantity::text,status`,[orderNumber,customerId,title,quantity,start,end,notes,user.id]);
        await audit(user.id,'PRODUCTION_ORDER_CREATED','PRODUCTION_ORDER',q.rows[0].id); await client.query('COMMIT'); return send(res,201,{order:q.rows[0]});
      } catch(e){await client.query('ROLLBACK');throw e;} finally{client.release();}
    }
    const productionStepMatch=url.pathname.match(/^\/api\/production-orders\/([0-9a-f-]{36})\/steps\/([0-9a-f-]{36})$/i);
    if(req.method==='POST'&&productionStepMatch){
      if(!user)return send(res,401,{error:'ابتدا وارد شوید.'}); if(!user.roles.some(r=>['OWNER','MANAGER'].includes(r)))return send(res,403,{error:'مجوز ثبت مرحله تولید را ندارید.'});
      const input=await body(req);const status=String(input.status||'COMPLETED');const notes=String(input.notes||'').trim()||null;
      if(!['STARTED','COMPLETED','BLOCKED','SKIPPED'].includes(status))return send(res,400,{error:'وضعیت مرحله معتبر نیست.'});
      const client=await pool.connect();try{await client.query('BEGIN');const order=await client.query('SELECT id,status FROM production_orders WHERE id=$1 FOR UPDATE',[productionStepMatch[1]]);const step=await client.query('SELECT id FROM production_steps WHERE id=$1 AND is_active=true',[productionStepMatch[2]]);
        if(!order.rowCount||!step.rowCount){await client.query('ROLLBACK');return send(res,404,{error:'سفارش یا مرحله تولید پیدا نشد.'});} if(order.rows[0].status==='CANCELLED'||order.rows[0].status==='COMPLETED'){await client.query('ROLLBACK');return send(res,409,{error:'برای سفارش تکمیل یا لغوشده امکان ثبت مرحله نیست.'});}
        const q=await client.query(`INSERT INTO production_step_logs(production_order_id,production_step_id,status,started_at,completed_at,operator_id,notes) VALUES($1,$2,$3,CASE WHEN $3='STARTED' THEN now() ELSE NULL END,CASE WHEN $3='COMPLETED' THEN now() ELSE NULL END,$4,$5) RETURNING id,status,created_at`,[productionStepMatch[1],productionStepMatch[2],status,user.id,notes]);
        if(order.rows[0].status==='PENDING')await client.query("UPDATE production_orders SET status='IN_PROGRESS',actual_start_at=COALESCE(actual_start_at,now()),updated_at=now() WHERE id=$1",[productionStepMatch[1]]);
        await audit(user.id,'PRODUCTION_STEP_LOGGED','PRODUCTION_ORDER',productionStepMatch[1]);await client.query('COMMIT');return send(res,201,{log:q.rows[0]});
      }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
    }
    const consumeMatch=url.pathname.match(/^\/api\/production-orders\/([0-9a-f-]{36})\/consume$/i);
    if(req.method==='POST'&&consumeMatch){
      if(!user)return send(res,401,{error:'ابتدا وارد شوید.'});if(!user.roles.some(r=>['OWNER','MANAGER'].includes(r)))return send(res,403,{error:'مجوز ثبت مصرف مواد را ندارید.'});
      const input=await body(req);const warehouseId=String(input.warehouseId||'');const productId=String(input.productId||'');const quantity=Number(input.quantity);const unitCost=Number(input.unitCostToman||0);const date=String(input.movementDate||'');const idem=String(req.headers['idempotency-key']||'').trim();
      if(!/^[0-9a-f-]{36}$/i.test(warehouseId)||!/^[0-9a-f-]{36}$/i.test(productId)||!Number.isFinite(quantity)||quantity<=0||!Number.isSafeInteger(unitCost)||unitCost<0||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(date)||!idem||idem.length>180)return send(res,400,{error:'انبار، ماده، مقدار، بهای واحد صحیح، تاریخ و کلید یکتا لازم است.'});
      const client=await pool.connect();try{await client.query('BEGIN');await client.query('SELECT pg_advisory_xact_lock(hashtext($1))',['production-consume:'+idem]);const dup=await client.query('SELECT id FROM production_consumptions WHERE stock_movement_id IN (SELECT id FROM stock_movements WHERE idempotency_key=$1)',[idem]);if(dup.rowCount){await client.query('ROLLBACK');return send(res,200,{consumptionId:dup.rows[0].id,duplicateRequest:true});}
        const po=await client.query('SELECT id,status FROM production_orders WHERE id=$1 FOR UPDATE',[consumeMatch[1]]);if(!po.rowCount||['COMPLETED','CANCELLED'].includes(po.rows[0].status)){await client.query('ROLLBACK');return send(res,409,{error:'سفارش تولید برای ثبت مصرف معتبر نیست.'});}
        await client.query('SELECT pg_advisory_xact_lock(hashtext($1))',[warehouseId+':'+productId]);const bal=await client.query('SELECT COALESCE(sum(quantity*direction),0)::numeric(14,3) balance FROM stock_movements WHERE warehouse_id=$1 AND product_id=$2',[warehouseId,productId]);if(Number(bal.rows[0].balance)<quantity){await client.query('ROLLBACK');return send(res,409,{error:`موجودی کافی نیست؛ موجودی فعلی ${bal.rows[0].balance} است.`});}
        const mv=await client.query(`INSERT INTO stock_movements(warehouse_id,product_id,movement_type,quantity,direction,movement_date,reference_type,reference_id,notes,created_by,idempotency_key) VALUES($1,$2,'PRODUCTION_CONSUMPTION',$3,-1,$4,'PRODUCTION_ORDER',$5,$6,$7,$8) RETURNING id`,[warehouseId,productId,quantity,date,consumeMatch[1],String(input.notes||'مصرف در سفارش تولید'),user.id,idem]);
        const total=Math.round(quantity*unitCost);if(!Number.isSafeInteger(total)){await client.query('ROLLBACK');return send(res,400,{error:'مبلغ بهای مواد خارج از محدوده است.'});}
        const c=await client.query('INSERT INTO production_consumptions(production_order_id,stock_movement_id,unit_cost_toman,quantity,total_cost_toman) VALUES($1,$2,$3,$4,$5) RETURNING id,total_cost_toman',[consumeMatch[1],mv.rows[0].id,unitCost,quantity,total]);
        await client.query("UPDATE production_orders SET status='IN_PROGRESS',actual_start_at=COALESCE(actual_start_at,now()),updated_at=now() WHERE id=$1",[consumeMatch[1]]);await audit(user.id,'PRODUCTION_MATERIAL_CONSUMED','PRODUCTION_ORDER',consumeMatch[1]);await client.query('COMMIT');return send(res,201,{consumption:c.rows[0],materialCostToman:total});
      }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
    }
    const outputMatch=url.pathname.match(/^\/api\/production-orders\/([0-9a-f-]{36})\/output$/i);
    if(req.method==='POST'&&outputMatch){
      if(!user)return send(res,401,{error:'ابتدا وارد شوید.'});if(!user.roles.some(r=>['OWNER','MANAGER'].includes(r)))return send(res,403,{error:'مجوز ثبت خروجی تولید را ندارید.'});
      const input=await body(req);const warehouseId=String(input.warehouseId||'');const productId=String(input.productId||'');const quantity=Number(input.quantity);const date=String(input.movementDate||'');const idem=String(req.headers['idempotency-key']||'').trim();
      if(input.verified!==true||!/^[0-9a-f-]{36}$/i.test(warehouseId)||!/^[0-9a-f-]{36}$/i.test(productId)||!Number.isFinite(quantity)||quantity<=0||!/^[0-9]{4}-[0-9]{2}-[0-9]{2}$/.test(date)||!idem||idem.length>180)return send(res,400,{error:'تأیید انسانی خروجی، انبار، کالای خروجی، تعداد، تاریخ و کلید یکتا لازم است.'});
      const client=await pool.connect();try{await client.query('BEGIN');await client.query('SELECT pg_advisory_xact_lock(hashtext($1))',['production-output:'+idem]);const dup=await client.query('SELECT id FROM stock_movements WHERE idempotency_key=$1',[idem]);if(dup.rowCount){await client.query('ROLLBACK');return send(res,200,{movementId:dup.rows[0].id,duplicateRequest:true});}
        const po=await client.query('SELECT id,quantity,produced_quantity,status FROM production_orders WHERE id=$1 FOR UPDATE',[outputMatch[1]]);const refs=await client.query('SELECT id FROM warehouses WHERE id=$1 AND is_active=true',[warehouseId]);const prod=await client.query('SELECT id FROM products WHERE id=$1 AND is_active=true',[productId]);if(!po.rowCount||!refs.rowCount||!prod.rowCount||['COMPLETED','CANCELLED'].includes(po.rows[0].status)){await client.query('ROLLBACK');return send(res,400,{error:'سفارش یا انبار یا کالای خروجی معتبر نیست.'});}
        if(Number(po.rows[0].produced_quantity)+quantity>Number(po.rows[0].quantity)){await client.query('ROLLBACK');return send(res,409,{error:'تعداد خروجی از مقدار سفارش بیشتر می‌شود.'});}
        const mv=await client.query(`INSERT INTO stock_movements(warehouse_id,product_id,movement_type,quantity,direction,movement_date,reference_type,reference_id,notes,created_by,idempotency_key) VALUES($1,$2,'PRODUCTION_OUTPUT',$3,1,$4,'PRODUCTION_ORDER',$5,$6,$7,$8) RETURNING id`,[warehouseId,productId,quantity,date,outputMatch[1],String(input.notes||'خروجی تأییدشده تولید'),user.id,idem]);
        const produced=Number(po.rows[0].produced_quantity)+quantity;const status=produced>=Number(po.rows[0].quantity)?'COMPLETED':'IN_PROGRESS';await client.query('UPDATE production_orders SET produced_quantity=$2,status=$3,actual_end_at=CASE WHEN $3=\'COMPLETED\' THEN now() ELSE actual_end_at END,updated_at=now() WHERE id=$1',[outputMatch[1],produced,status]);await audit(user.id,'PRODUCTION_OUTPUT_RECORDED','PRODUCTION_ORDER',outputMatch[1]);await client.query('COMMIT');return send(res,201,{movementId:mv.rows[0].id,producedQuantity:produced,status});
      }catch(e){await client.query('ROLLBACK');throw e;}finally{client.release();}
    }
    if (req.method === 'GET' && url.pathname === '/api/reports/financial-summary') {
      if (!user) return send(res, 401, { error: 'ابتدا وارد شوید.' });
      if (!user.roles.some(r => ['OWNER','MANAGER'].includes(r))) return send(res, 403, { error: 'مجوز مشاهده گزارش مالی را ندارید.' });
      const from = String(url.searchParams.get('from') || new Date(new Date().getFullYear(),0,1).toISOString().slice(0,10));
      const to = String(url.searchParams.get('to') || new Date().toISOString().slice(0,10));
      if (!/^\d{4}-\d{2}-\d{2}$/.test(from) || !/^\d{4}-\d{2}-\d{2}$/.test(to) || from > to) return send(res,400,{error:'بازه تاریخ معتبر نیست.'});
      const q = await pool.query(`SELECT a.code,a.name,a.account_type,
        COALESCE(sum(jl.debit_amount) FILTER (WHERE je.id IS NOT NULL),0)::text debit_total,COALESCE(sum(jl.credit_amount) FILTER (WHERE je.id IS NOT NULL),0)::text credit_total
        FROM accounting_accounts a LEFT JOIN journal_lines jl ON jl.accounting_account_id=a.id
        LEFT JOIN journal_entries je ON je.id=jl.journal_entry_id AND je.status='POSTED' AND je.entry_date BETWEEN $1 AND $2
        WHERE a.is_active=true GROUP BY a.id ORDER BY a.code`,[from,to]);
      const rows = q.rows.map((r:any)=>({ ...r, debit_total:Number(r.debit_total), credit_total:Number(r.credit_total), balance:
        r.account_type==='ASSET'||r.account_type==='EXPENSE' ? Number(r.debit_total)-Number(r.credit_total) : Number(r.credit_total)-Number(r.debit_total) }));
      const revenue = rows.filter((r:any)=>r.account_type==='REVENUE').reduce((a:number,r:any)=>a+r.balance,0);
      const expenses = rows.filter((r:any)=>r.account_type==='EXPENSE').reduce((a:number,r:any)=>a+r.balance,0);
      return send(res,200,{period:{from,to},currency:'TOMAN',revenue,expenses,net_result:revenue-expenses,accounts:rows});
    }
    return send(res, 404, { error: 'مسیر موردنظر پیدا نشد.' });
  } catch (error: any) {
    const message = error?.message === 'INVALID_JSON' ? 'ساختار اطلاعات ارسالی معتبر نیست.' : error?.message === 'BODY_TOO_LARGE' ? 'حجم درخواست بیش از حد مجاز است.' : 'خطای داخلی سرور.';
    if (error?.code === '23505') return send(res, 409, { error: 'این کد یا شماره قبلاً ثبت شده است.' });
    if (error?.code === '23514' && String(error?.constraint || '').includes('invoice_discount_not_over_subtotal')) return send(res, 400, { error: 'مجموع تخفیف‌ها نمی‌تواند از مبلغ ناخالص فاکتور بیشتر باشد.' });
    console.error('API error:', error?.message || error); return send(res, error?.message === 'INVALID_JSON' ? 400 : 500, { error: message });
  }
});

if (AUTH_SECRET.length < 32) throw new Error('AUTH_SECRET must be configured with at least 32 random characters before the API can start.');
server.listen(PORT, '0.0.0.0', () => console.log(`Workshop ERP API listening on ${PORT}`));
process.on('SIGTERM', async () => { server.close(); await pool.end(); });
