-- Version 0.8: controlled inventory ledger and idempotent stock operations.
ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS idempotency_key varchar(180);
CREATE UNIQUE INDEX IF NOT EXISTS stock_movements_idempotency_idx ON stock_movements(idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE INDEX IF NOT EXISTS stock_movements_warehouse_product_date_idx ON stock_movements(warehouse_id,product_id,movement_date DESC);
CREATE INDEX IF NOT EXISTS products_category_idx ON products(category);
ALTER TABLE stock_movements ADD CONSTRAINT stock_movement_direction_check CHECK (
 (movement_type IN ('OPENING','IN','RETURN','PRODUCTION_OUTPUT') AND direction=1) OR
 (movement_type IN ('OUT','PRODUCTION_CONSUMPTION') AND direction=-1) OR
 movement_type='ADJUSTMENT'
) NOT VALID;
CREATE OR REPLACE FUNCTION prevent_stock_movement_mutation() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN RAISE EXCEPTION 'STOCK_MOVEMENTS_ARE_IMMUTABLE'; END; $$;
DROP TRIGGER IF EXISTS stock_movements_immutable ON stock_movements;
CREATE TRIGGER stock_movements_immutable BEFORE UPDATE OR DELETE ON stock_movements FOR EACH ROW EXECUTE FUNCTION prevent_stock_movement_mutation();
