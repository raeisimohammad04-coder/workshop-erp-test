-- Version 0.6: minimum chart of accounts and enforced balanced journal posting.
INSERT INTO accounting_accounts(code,name,account_type) VALUES
 ('1000','دارایی‌ها','ASSET'),
 ('1010','صندوق و بانک','ASSET'),
 ('1100','حساب‌های دریافتنی مشتریان','ASSET'),
 ('2000','بدهی‌ها','LIABILITY'),
 ('3000','سرمایه و حقوق مالکانه','EQUITY'),
 ('4000','درآمد فروش و خدمات','REVENUE'),
 ('5000','هزینه‌های عملیاتی','EXPENSE'),
 ('5100','تخفیفات فروش','EXPENSE')
ON CONFLICT (code) DO NOTHING;

ALTER TABLE journal_entries ADD COLUMN IF NOT EXISTS posted_by uuid REFERENCES users(id);
ALTER TABLE journal_lines ADD COLUMN IF NOT EXISTS financial_account_id uuid REFERENCES financial_accounts(id);
CREATE UNIQUE INDEX IF NOT EXISTS journal_source_once_idx
 ON journal_entries(source_type,source_id) WHERE source_type IS NOT NULL AND source_id IS NOT NULL AND status='POSTED';

CREATE OR REPLACE FUNCTION enforce_balanced_journal_posting() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE deb bigint; cred bigint; line_count integer; should_validate boolean := false;
BEGIN
  IF TG_OP='INSERT' THEN
    should_validate := NEW.status='POSTED';
  ELSIF TG_OP='UPDATE' THEN
    should_validate := NEW.status='POSTED' AND OLD.status IS DISTINCT FROM 'POSTED';
  END IF;
  IF should_validate THEN
    SELECT COALESCE(sum(debit_amount),0), COALESCE(sum(credit_amount),0), count(*)
      INTO deb,cred,line_count FROM journal_lines WHERE journal_entry_id=NEW.id;
    IF line_count < 2 OR deb=0 OR deb<>cred THEN
      RAISE EXCEPTION 'JOURNAL_NOT_BALANCED';
    END IF;
    NEW.posted_at := COALESCE(NEW.posted_at,now());
  END IF;
  IF TG_OP='UPDATE' THEN
    IF OLD.status='POSTED' AND (
      NEW.entry_date IS DISTINCT FROM OLD.entry_date OR NEW.description IS DISTINCT FROM OLD.description OR
      NEW.source_type IS DISTINCT FROM OLD.source_type OR NEW.source_id IS DISTINCT FROM OLD.source_id OR
      NEW.status IS DISTINCT FROM OLD.status
    ) THEN RAISE EXCEPTION 'POSTED_JOURNAL_IMMUTABLE'; END IF;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS journal_posting_guard ON journal_entries;
CREATE TRIGGER journal_posting_guard BEFORE INSERT OR UPDATE ON journal_entries
FOR EACH ROW EXECUTE FUNCTION enforce_balanced_journal_posting();

CREATE OR REPLACE FUNCTION guard_posted_journal_lines() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE entry_status text; entry_id_value uuid;
BEGIN
  entry_id_value := CASE WHEN TG_OP='DELETE' THEN OLD.journal_entry_id ELSE NEW.journal_entry_id END;
  SELECT status INTO entry_status FROM journal_entries WHERE id=entry_id_value FOR UPDATE;
  IF entry_status='POSTED' THEN RAISE EXCEPTION 'POSTED_JOURNAL_LINES_IMMUTABLE'; END IF;
  IF TG_OP='DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS journal_lines_posted_guard ON journal_lines;
CREATE TRIGGER journal_lines_posted_guard BEFORE INSERT OR UPDATE OR DELETE ON journal_lines
FOR EACH ROW EXECUTE FUNCTION guard_posted_journal_lines();

CREATE INDEX IF NOT EXISTS journal_lines_account_idx ON journal_lines(accounting_account_id);
