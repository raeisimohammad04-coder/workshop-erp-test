-- Version 0.9: production workflow, verified output and traceable material consumption.
ALTER TABLE production_orders ADD COLUMN IF NOT EXISTS produced_quantity numeric(14,3) NOT NULL DEFAULT 0 CHECK (produced_quantity >= 0);
ALTER TABLE production_orders ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE production_orders ADD CONSTRAINT production_order_status_check CHECK (status IN ('PENDING','IN_PROGRESS','COMPLETED','CANCELLED')) NOT VALID;
CREATE INDEX IF NOT EXISTS production_orders_status_date_idx ON production_orders(status, planned_start_date DESC);
CREATE INDEX IF NOT EXISTS production_step_logs_order_idx ON production_step_logs(production_order_id, created_at DESC);
CREATE TABLE IF NOT EXISTS production_consumptions (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 production_order_id uuid NOT NULL REFERENCES production_orders(id),
 stock_movement_id uuid NOT NULL UNIQUE REFERENCES stock_movements(id),
 unit_cost_toman bigint NOT NULL DEFAULT 0 CHECK(unit_cost_toman >= 0),
 quantity numeric(14,3) NOT NULL CHECK(quantity > 0),
 total_cost_toman bigint NOT NULL CHECK(total_cost_toman >= 0),
 created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS production_consumptions_order_idx ON production_consumptions(production_order_id);
INSERT INTO production_steps(name,sort_order) VALUES
 ('دریافت و بررسی سفارش',10),('آماده‌سازی پارچه و روسری',20),('آماده‌سازی رنگ',30),('رنگرزی',40),('آبکشی و تثبیت رنگ',50),('خشک‌کردن',60),('کنترل کیفیت',70),('بسته‌بندی و تحویل',80)
ON CONFLICT DO NOTHING;
