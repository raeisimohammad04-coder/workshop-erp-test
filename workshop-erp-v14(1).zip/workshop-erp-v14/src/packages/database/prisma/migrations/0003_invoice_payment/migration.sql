-- Invoice lifecycle and payment integrity (all monetary values are integer toman).
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS updated_at timestamptz NOT NULL DEFAULT now();
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS finalized_by uuid REFERENCES users(id);
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS source varchar(30) NOT NULL DEFAULT 'CURRENT'
  CHECK (source IN ('CURRENT','HISTORICAL_IMPORT'));
ALTER TABLE invoices ADD CONSTRAINT invoice_discount_not_over_subtotal CHECK (discount_amount <= subtotal);
CREATE INDEX IF NOT EXISTS invoices_status_date_idx ON invoices(status, issue_date DESC);
CREATE INDEX IF NOT EXISTS payment_allocations_invoice_idx ON payment_allocations(invoice_id);

CREATE OR REPLACE FUNCTION guard_finalized_invoice() RETURNS trigger LANGUAGE plpgsql AS $$
BEGIN
  IF OLD.status <> 'DRAFT' THEN
    IF TG_OP = 'DELETE' THEN RAISE EXCEPTION 'FINALIZED_INVOICE_IMMUTABLE'; END IF;
    IF NEW.customer_id IS DISTINCT FROM OLD.customer_id
      OR NEW.invoice_number IS DISTINCT FROM OLD.invoice_number
      OR NEW.issue_date IS DISTINCT FROM OLD.issue_date
      OR NEW.subtotal IS DISTINCT FROM OLD.subtotal
      OR NEW.discount_amount IS DISTINCT FROM OLD.discount_amount
      OR NEW.total_amount IS DISTINCT FROM OLD.total_amount
      OR NEW.notes IS DISTINCT FROM OLD.notes
      OR NEW.source IS DISTINCT FROM OLD.source THEN
      RAISE EXCEPTION 'FINALIZED_INVOICE_IMMUTABLE';
    END IF;
  END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS invoices_immutable_guard ON invoices;
CREATE TRIGGER invoices_immutable_guard BEFORE UPDATE OR DELETE ON invoices
FOR EACH ROW EXECUTE FUNCTION guard_finalized_invoice();

CREATE OR REPLACE FUNCTION guard_invoice_item_draft() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE invoice_status text; invoice_id_value uuid;
BEGIN
  invoice_id_value := CASE WHEN TG_OP='DELETE' THEN OLD.invoice_id ELSE NEW.invoice_id END;
  SELECT status INTO invoice_status FROM invoices WHERE id = invoice_id_value FOR UPDATE;
  IF invoice_status IS DISTINCT FROM 'DRAFT' THEN RAISE EXCEPTION 'INVOICE_ITEMS_LOCKED'; END IF;
  IF TG_OP='DELETE' THEN RETURN OLD; END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS invoice_items_draft_guard ON invoice_items;
CREATE TRIGGER invoice_items_draft_guard BEFORE INSERT OR UPDATE OR DELETE ON invoice_items
FOR EACH ROW EXECUTE FUNCTION guard_invoice_item_draft();

CREATE OR REPLACE FUNCTION guard_payment_allocation() RETURNS trigger LANGUAGE plpgsql AS $$
DECLARE p_amount bigint; p_reversed timestamptz; i_total bigint; i_status text; allocated bigint;
BEGIN
  IF TG_OP='DELETE' THEN RAISE EXCEPTION 'PAYMENT_ALLOCATIONS_ARE_IMMUTABLE'; END IF;
  SELECT amount, reversed_at INTO p_amount, p_reversed FROM payments WHERE id = NEW.payment_id FOR UPDATE;
  SELECT total_amount, status INTO i_total, i_status FROM invoices WHERE id = NEW.invoice_id FOR UPDATE;
  IF p_reversed IS NOT NULL OR i_status NOT IN ('FINALIZED','PARTIALLY_PAID','PAID') THEN RAISE EXCEPTION 'INVALID_ALLOCATION_TARGET'; END IF;
  SELECT COALESCE(sum(allocated_amount),0) INTO allocated FROM payment_allocations WHERE payment_id=NEW.payment_id AND id IS DISTINCT FROM NEW.id;
  IF allocated + NEW.allocated_amount > p_amount THEN RAISE EXCEPTION 'PAYMENT_OVERALLOCATED'; END IF;
  SELECT COALESCE(sum(allocated_amount),0) INTO allocated FROM payment_allocations WHERE invoice_id=NEW.invoice_id AND id IS DISTINCT FROM NEW.id;
  IF allocated + NEW.allocated_amount > i_total THEN RAISE EXCEPTION 'INVOICE_OVERPAID'; END IF;
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS payment_allocation_guard ON payment_allocations;
CREATE TRIGGER payment_allocation_guard BEFORE INSERT OR UPDATE OR DELETE ON payment_allocations
FOR EACH ROW EXECUTE FUNCTION guard_payment_allocation();
INSERT INTO financial_accounts(name,type,opening_balance)
SELECT 'صندوق اصلی','CASH',0
WHERE NOT EXISTS (SELECT 1 FROM financial_accounts WHERE type='CASH' AND is_active=true);
CREATE TABLE IF NOT EXISTS invoice_status_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  invoice_id uuid NOT NULL REFERENCES invoices(id),
  old_status varchar(30),
  new_status varchar(30) NOT NULL,
  reason text,
  changed_by uuid NOT NULL REFERENCES users(id),
  created_at timestamptz NOT NULL DEFAULT now()
);
