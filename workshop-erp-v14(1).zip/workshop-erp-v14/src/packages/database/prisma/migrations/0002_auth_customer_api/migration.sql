-- Session expiry and customer lookup indexes
CREATE INDEX IF NOT EXISTS customers_name_idx ON customers (full_name);
CREATE INDEX IF NOT EXISTS customers_phone_idx ON customers (phone);
CREATE INDEX IF NOT EXISTS sessions_user_expiry_idx ON sessions (user_id, expires_at);
-- The first owner is created only through the one-time setup endpoint.
