-- Owner-controlled target profit per scarf. Stored as an integer number of toman.
CREATE TABLE IF NOT EXISTS app_settings (
  setting_key text PRIMARY KEY,
  setting_value text NOT NULL,
  updated_by uuid REFERENCES users(id),
  updated_at timestamptz NOT NULL DEFAULT now()
);
INSERT INTO app_settings(setting_key, setting_value)
VALUES ('profit_per_scarf_toman', '200000')
ON CONFLICT (setting_key) DO NOTHING;
