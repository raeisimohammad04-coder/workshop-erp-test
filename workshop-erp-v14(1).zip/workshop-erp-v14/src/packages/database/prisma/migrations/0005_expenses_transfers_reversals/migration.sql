-- Version 0.7: operational expenses, internal account transfers and auditable payment reversals.
INSERT INTO expense_categories(name) VALUES
 ('مواد مصرفی'),('دستمزد'),('آب و برق و انرژی'),('تعمیر و نگهداری'),('حمل‌ونقل'),('اجاره'),('سایر هزینه‌ها')
ON CONFLICT (name) DO NOTHING;

CREATE INDEX IF NOT EXISTS expenses_date_idx ON expenses(expense_date DESC);
CREATE INDEX IF NOT EXISTS expenses_account_date_idx ON expenses(financial_account_id,expense_date DESC);
CREATE INDEX IF NOT EXISTS account_transfers_date_idx ON account_transfers(transfer_date DESC);
CREATE INDEX IF NOT EXISTS payments_reversed_idx ON payments(reversed_at) WHERE reversed_at IS NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS journal_source_once_idx
 ON journal_entries(source_type,source_id)
 WHERE source_type IS NOT NULL AND source_id IS NOT NULL AND status='POSTED';
