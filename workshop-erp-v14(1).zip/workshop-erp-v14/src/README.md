# Workshop ERP

نرم‌افزار مستقل مدیریت کارگاه رنگرزی؛ رابط فارسی و PWA، API و PostgreSQL. نسخه توسعه‌ای ۰.۱۴. تمام مبالغ در دیتابیس با واحد تومان و به‌صورت عدد صحیح ذخیره می‌شوند.

## پیش‌نیاز اجرا
- Node.js 22 یا نسخه LTS سازگار
- pnpm 10
- PostgreSQL 16 یا جدیدتر
- Docker Compose (برای راه‌اندازی ساده‌تر سرویس‌ها)

## تنظیمات
۱. فایل `.env.example` را به `.env` کپی کنید.
۲. `DATABASE_URL`، `AUTH_SECRET` و `SETUP_TOKEN` را تنظیم کنید؛ هر دو راز باید حداقل ۳۲ نویسه تصادفی و متفاوت باشند. توکن راه‌اندازی فقط برای ساخت مالک اولیه استفاده می‌شود.
۳. سرویس PostgreSQL را اجرا کنید.
۴. migrationها را با `pnpm db:migrate:sql` اجرا کنید.
۵. وابستگی‌ها را با `pnpm install` نصب کنید.
۶. API و وب را در دو ترمینال اجرا کنید: `pnpm dev:api` و `pnpm dev:web`.

## هشدار
این پروژه هنوز نسخه توسعه‌ای است و تا اجرای تست‌های end-to-end، تست بازیابی backup، بررسی امنیتی و تکمیل ثبت‌های مالی برای داده واقعی کارگاه مناسب نیست.

جزئیات وضعیت در `docs/BUILD_STATUS.md` آمده است.

## قابلیت‌های پایه نسخه‌های اولیه
- ثبت هزینه با دسته‌بندی، حساب پرداخت‌کننده و سند حسابداری خودکار.
- ثبت انتقال بین صندوق و بانک بدون اثر بر درآمد یا هزینه.
- برگشت دریافت با دلیل، سند معکوس دفتر کل و به‌روزرسانی وضعیت فاکتور.
- کلید Idempotency برای جلوگیری از ثبت تکراری هزینه و انتقال.
- صفحات فارسی هزینه‌ها و انتقال بین حساب‌ها.


### نسخه ۰.۸ — انبار
در این نسخه تعریف انبار، تعریف کالا/مواد اولیه، ثبت ورود و خروج، ثبت موجودی افتتاحیه، نمایش موجودی به تفکیک انبار و هشدار حداقل موجودی اضافه شده است. گردش‌های انبار دفترکل غیرقابل‌ویرایش هستند. خروج بیش از موجودی موجود رد می‌شود. قبل از استفاده واقعی، migration شماره 0006 را روی پایگاه داده پشتیبان‌گیری‌شده اجرا کنید.


## نسخه ۰.۹ — تولید
برای جزئیات سفارش‌های تولید، گردش مراحل، مصرف مواد و ثبت خروجی تأییدشده، سند `docs/V09_PRODUCTION.md` را ببینید.


### Owner profit setting (v0.10)
After database migrations, the owner can open **تنظیمات مالک** and set the target profit per scarf. The initial value is 200,000 toman. Production order rows show this target and, when a tracked unit cost is available, an indicative target sale price. This is not realized profit.


## نسخه ۰.۱۱ — پرونده مالی مشتری
در فهرست مشتریان با انتخاب نام هر مشتری، پرونده مالی او باز می‌شود. این صفحه جمع فاکتورهای قطعی، پرداخت تخصیص‌یافته، مانده حساب، جزئیات فاکتورها و دریافت‌های ثبت‌شده را نمایش می‌دهد. دریافت‌های تاریخی از دریافت‌های جاری تفکیک می‌شوند و دریافت برگشت‌خورده در جمع‌ها وارد نمی‌شود. این نسخه ماژول حقوق و دستمزد را فعال یا توسعه نمی‌دهد.


### Version 0.12.0 — customer receipt workflow
From a customer's financial statement, select **ثبت دریافت** next to an outstanding finalized invoice. Choose the receiving account, amount, date, and method. The API validates the balance and atomically creates the payment, invoice allocation, double-entry journal, idempotency record, and audit entry. Payroll is not included.


### Version 0.14.0 — Tehran date and setup protection
- Payment reversal date uses `(CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Tehran')::date`, independent of the PostgreSQL server timezone.
- Initial owner setup is limited to five attempts per 15 minutes per remote IP, with HTTP 429 and `Retry-After`. This is an in-memory, single-process guard; it is not a substitute for a shared production rate limiter.
- The health endpoint and package versions report 0.14.0.
- Login rate limiting, HttpOnly cookie sessions, user administration, fine-grained read permissions, full accounting/costing, idempotency fingerprints, PostgreSQL runtime tests, backup/restore drills, and HTTPS deployment remain open.

### Version 0.13.0 — critical integrity fixes
- Request bodies are now assembled as UTF-8 bytes and limited by byte length.
- Initial owner creation requires the server-side `SETUP_TOKEN` and uses a PostgreSQL transaction advisory lock to prevent concurrent first-owner creation.
- Payment reversal locks all affected invoices in deterministic ID order before recalculating balances and posts the reversal using the current database date.
- Account transfer rows are locked in deterministic ID order.
- Invoice discounts are validated together before insert and the matching database constraint is translated to HTTP 400.
- Health endpoint reports 0.13.0.
- Still not production-approved: PostgreSQL runtime, full builds, concurrency/E2E tests, cookie-based sessions, rate limiting, user administration, and accounting/inventory integration remain outstanding.

- `AUTH_SECRET` اکنون در مشتق‌سازی هش نشست‌ها استفاده می‌شود و API با مقدار کمتر از ۳۲ نویسه راه‌اندازی نمی‌شود. با تغییر AUTH_SECRET، نشست‌های قبلی معتبر نخواهند بود و کاربران باید دوباره وارد شوند.
